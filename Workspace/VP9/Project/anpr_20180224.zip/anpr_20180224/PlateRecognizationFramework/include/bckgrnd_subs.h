#ifndef BCKGRND_SUBS
#define BCKGRND_SUBS

#include <iostream>
#include <vector>
#include <chrono>
#include <mutex>

using namespace cv;
using namespace std;



vector<cv::Rect> Object_detection(Mat framein);

#endif