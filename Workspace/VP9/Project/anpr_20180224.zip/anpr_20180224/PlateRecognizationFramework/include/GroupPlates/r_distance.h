#ifndef R_DISTANCE
#define R_DISTANCE

#include <iostream>
#include <vector>
#include <chrono>
#include <mutex>

using namespace cv;
using namespace std;

double d_dist(double p11x,double p11y,double p22x,double p22y);
#endif