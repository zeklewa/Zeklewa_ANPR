#ifndef PLATE_DETECTOR_INPUT_DATA_H
#define PLATE_DETECTOR_INPUT_DATA_H

namespace pr{
	class PlateDetectorInputData{

	};
}

#endif