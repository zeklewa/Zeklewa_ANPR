#include "IPlateDetect.h"

using namespace pr;

std::vector<PlateRegion> IPlateDetect::GetPlateRegions()
{	
	return std::vector<PlateRegion>();
}

