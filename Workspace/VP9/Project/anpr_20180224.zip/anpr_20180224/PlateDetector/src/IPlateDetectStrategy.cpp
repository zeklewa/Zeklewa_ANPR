#include "IPlateDetectStrategy.h"

using namespace pr;

std::vector<PlateRegion> IPlateDetectStrategy::GetPlateRegions(PlateDetectorInputData* data)
{
	return std::vector<PlateRegion>();
}
